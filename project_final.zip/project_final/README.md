# Programming 3 example (by ananun)

This is code example of Tumos project GameOfLife with server side programming.

## Installation

Use the node package manager [npm](https://www.npmjs.com/) to install project modules.

```bash
npm install
```

It will installs [express.js](https://expressjs.com/) and [socket.io](https://socket.io/)

After that you can run server by typing.

```bash
npm start
```

Server will start on Port 3000