let Liveform = require('./LiveForm')

module.exports = class End extends Liveform {
	constructor(x, y) {
		super(x, y)
	}

	getRndInteger(min, max) {
		return super.getRndInteger(min, max)
	}

	destruction() {
		let x = this.getRndInteger(0, 34)
		let y = this.getRndInteger(0, 34)
		if (weather == 'summer' && matrix[y][x] !== 4) {
			matrix[y][x] = 5
		}

		if (weather == 'spring' && matrix[y][x] == 6) {
			matrix[y][x] = 5
		}
	}
}