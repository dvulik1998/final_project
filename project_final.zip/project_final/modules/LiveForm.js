module.exports = class LiveForm {
    constructor(x, y) {
        this.x = x
        this.y = y
    }
    chooseCells(t) {
        var found = []
        for (var i in this.directions) {
            var x = this.directions[i][0]
            var y = this.directions[i][1]
            if (x >= 0 && x < matrix[0].length && y >= 0 && y < matrix.length) {
                if (matrix[y][x] == t) {
                    found.push(this.directions[i])
                }
            }
        }
        return found;
    }

    getRndInteger(min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

    getNewCoordinates() {
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1]
        ]
    }

    die(p_arr) {
        matrix[this.y][this.x] = 0;
        for (let i in p_arr) {
            if (p_arr[i].x == this.x && p_arr[i].y == this.y) {
                p_arr.splice(i, 1)
            }
        }
    }
}
