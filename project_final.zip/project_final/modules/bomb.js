let Liveform = require('./LiveForm')
let Grass = require('./Grass')
let GrassEater = require('./GrassEater')

module.exports = class Arc extends Liveform {
	constructor(x, y) {
		super(x, y)
		this.life = 10
	}

	getRndInteger(start, stop) {
		return super.getRndInteger(start, stop)
	}

	again() {
		if (grassArr.length == 0) {
			let grass = new Grass(this.getRndInteger(0, 34), this.getRndInteger(0, 34))
			grassHashiv++
			reanimated++
			grassArr.push(grass)
			if (matrix[this.y][this.x] !== 4) {
				matrix[this.y][this.x] = 0
			}
		}
		else if (grassEaterArr.length == 0) {
			let eat = new GrassEater(this.getRndInteger(0, 34), this.getRndInteger(0, 34))
			eater++
			reanimated++
			grassEaterArr.push(eat)
			if (matrix[this.y][this.x] !== 4) {
				matrix[this.y][this.x] = 0
			}
		}

		else if (weather == 'autumn') {
			let x = this.getRndInteger(0, 34)
			let y = this.getRndInteger(0, 34)
			matrix[y][x] == 0
		}
	}
}



