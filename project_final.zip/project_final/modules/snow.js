let LiveForm = require('./LiveForm')

module.exports = class Snow extends LiveForm {
    constructor(x, y) {
        super(x, y)
    }
    
    temp(change, subst) {
        for (let i = 0; i < matrix.length; i++) {
            for (let j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == change) {
                    matrix[i][j] = subst
                }
            }
        }
    }
    appear() {
        if (weather == 'winter') {
            this.temp(5, 6)
        }
        if (weather == 'summer') {
            this.temp(6, 5)
        }
        
    }
}