let Liveform = require('./LiveForm')
let random = require('./random')

module.exports = class Rude extends Liveform {
	constructor(x, y) {
		super(x, y)
		this.water = 0
	}
	//coordinate function
	getNewCoordinates() {
		return super.getNewCoordinates()
	}

	chooseCells(char) {
		return super.chooseCells(char)
	}

	move() {
		//move
		this.getNewCoordinates()
		let movecoord = random(this.chooseCells(0))

		if (movecoord) {
			let newX = movecoord[0]
			let newY = movecoord[1]

			matrix[this.y][this.x] = 0
			matrix[newY][newX] = 3

			this.x = newX
			this.y = newY
		}
		if (weather == 'autumn') {
            for (let i  = 0; i < matrix.length; i++){
                for (let j = 0; j < matrix[i].length; j++) {
                    matrix[i][j] = 0
                }
            }
        }
	}
	mul() {
        let emptyCells = this.chooseCells(0);
        let newCell = random(emptyCells);

        if (newCell) {
            let x = newCell[0];
            let y = newCell[1];
            matrix[y][x] = 3
            let wild = new Rude(x, y);
            wildo.push(wild);
        }
    }

	eat() {
		this.getNewCoordinates()
		let eatercells = random(this.chooseCells(2))
		let chance = random(this.chooseCells(5))
		// let stop = random(this.chooseCells(6))
		if (eatercells) {
			let x_1 = eatercells[0]
			let y_1 = eatercells[1]

			matrix[y_1][x_1] = 3
			matrix[this.y][this.x] = 0

			this.x = x_1
			this.y = y_1

			for (let i in grassEaterArr) {
				if (grassEaterArr[i].x == x_1 && grassEaterArr[i].y == y_1) {
					grassEaterArr.splice(i, 1)
					food++
				}
			}
		}

		else if (chance) {
			this.water++
			let x_1 = chance[0]
			let y_1 = chance[1]
			matrix[y_1][x_1] = 3
			matrix[this.y][this.x] = 0

			for (let i in ocean) {
				if (ocean[i].x == x_1 && ocean[i].y == y_1) {
					ocean.splice(i, 1)
					food++
				}
			}
			this.x = x_1
			this.y = y_1

			if (this.water > 15) {
				if (weather == 'summer') {
					this.mul()
				}
				this.water = 0
			}
		}
		else {
			this.move()
		}
	}
	//die
	die(ruder) {
        return super.die(ruder)
    }
}
